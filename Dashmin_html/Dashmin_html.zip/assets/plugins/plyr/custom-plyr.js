/*---------------------------------------------
Template name :  My Website
Version       :  1.0
Author        :  ThemeLooks
Author url    :  http://themelooks.com


** Custom Plyr JS

----------------------------------------------*/
$(function () {
	'use strict';

	$(document).ready(function () {
		new Plyr('.video-player'), new Plyr('.audio-player');
	});
});
